
/* memory dump */

#include "STDIO.TXT"
#include "ALLOC.TXT"
#include "STRING.TXT"

int main()
{
	int		d, i, sadr, eadr;
	char    sttadr[12], endadr[12];
	char	ch, *pa;
	char	msttadr[12];
	char    mendadr[12];
	char	header[80];

	strcpy(msttadr, "sttadr= $");
	strcpy(mendadr, "endadr= $");
	strcpy(header, "      +0 +1 +2 +3 +4 +5 +6 +7 +8 +9 +A +B +C +D +E +F  0123456789ABCDEF");

    /* input disp adrs area */
    printf(msttadr);
	i = 0;
    while ((ch = getchar()) != '\n' && i < 12) {
		sttadr[i++] = ch;
    }
	sttadr[i] = '\0';

    printf("\n%s", mendadr);
	i = 0;
    while ((ch = getchar()) != '\n' && i < 12) {
        endadr[i++] = ch;
    }
	endadr[i] = '\0';

    printf("\n");
    sadr = asc2bin(sttadr[0])*0x1000+asc2bin(sttadr[1])*0x100
    		+asc2bin(sttadr[2])*0x10+asc2bin(sttadr[3]);
    eadr = asc2bin(endadr[0])*0x1000+asc2bin(endadr[1])*0x100
    		+asc2bin(endadr[2])*0x10+asc2bin(endadr[3]);

	/* disp memory data */
    sadr &= 0xfff0; 
    do {
        printf("\n%s\n", header);
        do {
    		pa = sadr;
            printf("%04x: ", sadr);				/* disp adrs */
            for (i=0; i<16; i++) {
            	ch = *(pa+i) & 0xff;
            	if (ch >= 0 && ch < 0x10)
              		printf("%c%x ", '0', ch & 0xff);	/* disp data by hex */
            	else
            		printf("%x ", ch & 0xff);
            }
            putchar(' ');
            for (i=0; i<16; i++) {
                d = *(pa+i);
                ch = (d>=0x20 & d<=0x7e)?d:'.';
                putchar(ch);					/* disp data by ascii */
            }
            printf("\n");
            sadr += 0x10;
        } while ((sadr < eadr) && (sadr & 0xff) != 0);
    } while (sadr < eadr);
    printf("\n");
}

/* asc to bin */
asc2bin(ch)
char ch;
{
	return (ch>=0 && ch<0x39)?ch-0x30:ch-0x37;
}
