These are all the files contained in HDRELEASE.zip & what they do.

HDWRK.DSK - The WORK disk to use for the installation of a new drive.

Hd-rom.bin - ROM image file of the FLEX IDE drivers for use with PC based programmers.

HDSYS.DSK - The SYSTEM [boot] disk to use for the installation of a new drive. For DC-4 type systems.

HARDRIVE.TXT - Step by step instructions for setting up a new IDE drive.

netpc34.zip - If you don't already have it. You will need to install this to get the .DSK files onto real floppy disks.

pia-ide_anc.pcb - The PC board layout for the SS-30 IDE host adaptor. You need ExpressPCB* to read.

pia-ide_anc.sch - The schematic of the SS-30 IDE host adaptor. You need ExpressPCB* to read.

PROMIMG.DSK - The same thing as Hd-rom.bin & Sbugh1-8.bin in the format needed by 6809 based programmers.

Sbugh1-8.bin - ROM image file of SBUG-E V1.8 modified with the "P" command [punch tape] removed and replaced with an "H" command [Hard disk boot.] For use with PC based programmers.

SysList.txt - A file like the one you are reading explaining what is on HDSYS.DSK

WrkList.txt - A file like the one you are reading explaining what is on HDWRK.DSK

*Express PCB software is downloadable free from http://www.expresspcb.com